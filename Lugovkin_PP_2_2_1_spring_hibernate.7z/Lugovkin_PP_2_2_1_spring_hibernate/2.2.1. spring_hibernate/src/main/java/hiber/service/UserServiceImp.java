package hiber.service;

import hiber.dao.UserDao;
import hiber.model.Car;
import hiber.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserServiceImp implements UserService {

   @Autowired
   private UserDao userDao;

   @Transactional
   @Override
   public void add(User user) {
      userDao.add(user);
   }

   @Transactional(readOnly = true)
   @Override
   public List<User> listUsers() {
      return userDao.listUsers();
   }

   public void addUserWithCar() {
      User user1 = new User("User1", "Lastname1", "user1@mail.ru");
      Car car1 = new Car("Model1", 1);
      user1.setCar(car1);

      User user2 = new User("User2", "Lastname2", "user2@mail.ru");
      Car car2 = new Car("Model2", 2);
      user2.setCar(car2);

      User userPuk = new User("Puk", "AI", "puk_ai@email.com");
      Car carPuk = new Car("Toyota", 2024);
      userPuk.setCar(carPuk);

      userDao.add(user1);
      userDao.add(user2);
      userDao.add(userPuk);
   }
}