package hiber;

import hiber.config.AppConfig;
import hiber.model.User;
import hiber.service.UserService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.sql.SQLException;
import java.util.List;

public class MainApp {
   public static void main(String[] args) throws SQLException {
      AnnotationConfigApplicationContext context = 
            new AnnotationConfigApplicationContext(AppConfig.class);

      UserService userService = context.getBean(UserService.class);

      userService.add(new User("User1", "Lastname1", "user1@mail.ru"));
      userService.add(new User("User2", "Lastname2", "user2@mail.ru"));
      userService.add(new User("User3", "Lastname3", "user3@mail.ru"));
      userService.add(new User("User4", "Lastname4", "user4@mail.ru"));
      userService.addUserWithCar();
      List<User> users = userService.listUsers();
      for (User user : users) {
         System.out.println("Id = "+user.getId());
         System.out.println("First Name = "+user.getFirstName());
         System.out.println("Last Name = "+user.getLastName());
         System.out.println("Email = "+user.getEmail());
         System.out.println();
      }

      context.close();
   }
}
/* Вывод в консоль:
Hibernate: alter table users drop foreign key FK4hs22bt63vn34r1hq9qbrx6qc
Hibernate: drop table if exists car
Hibernate: drop table if exists users
Hibernate: create table car (id bigint not null auto_increment, model varchar(255), series integer not null, primary key (id)) engine=InnoDB
Hibernate: create table users (car_id bigint not null, email varchar(255), name varchar(255), last_name varchar(255), primary key (car_id)) engine=InnoDB
Hibernate: alter table users add constraint FK4hs22bt63vn34r1hq9qbrx6qc foreign key (car_id) references car (id)
 */