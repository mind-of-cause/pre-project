package hiber.dao;

import hiber.model.User;

import java.util.List;

public interface UserDao {
   void add(User user);
   List<User> listUsers();
   public User getUserWithCarModelAndSeries(String model, int series);

    void addUserWithCar(String firstName, String lastName, String email, String carModel, int carSeries);
}
